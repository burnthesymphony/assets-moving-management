<?php get_header(); ?>

	<div id="content_top"><!-- nothing to see here --></div>
	<div id="content_wrapper">
		<div id="main">
			<div class="the_post"> 
                <h2>Sorry, but what you are looking for isn't here...</h2>
            </div> <!-- the_post -->
		</div> <!-- main -->
	
		<?php get_sidebar(); ?>
	</div> <!-- content_wrapper -->
	<div id="content_bottom"><!-- nothing to see here --></div>

<?php get_footer(); ?>