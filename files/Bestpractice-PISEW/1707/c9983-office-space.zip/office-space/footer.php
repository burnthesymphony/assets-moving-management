	<div id="footer">
		<?php if (get_option(THEME_PREFIX . "copy_text")) { ?>
		<h2>Copyright <?php echo date("Y"); ?> <?php echo get_option(THEME_PREFIX . "copy_text"); ?> - All Rights Reserved</h2>
		<?php } ?>
		
		<?php if (get_option(THEME_PREFIX . "footer_text")) : ?>
		<p><?php echo get_option(THEME_PREFIX . "footer_text"); ?></p>
		<?php else : ?>
		<p>Site Design by <a href="http://www.press75.com/" title="Press75.com" >Press75.com</a> &amp; Powered by <a href="http://www.wordpress.org/" target="_blank" title="WordPress.org">WordPress</a></p>
		<?php endif; ?>
	</div>
        
</div> <!-- end wrapper -->

<?php wp_footer(); ?>

</body>
</html>