<?php get_header(); ?>

	<div id="content_top"><!-- nothing to see here --></div>
	<div id="content_wrapper">
		<div id="home_featured">
			<div class="main_image">
				<?php
					$cat = get_option(THEME_PREFIX . "feature_carousel");
					query_posts("cat=$cat&showposts=5");
				?>
				<?php if (have_posts()) : the_post(); ?>
			
				<?php the_post_thumbnail('featured'); ?>
				
				<div class="desc">
					<a href="#" class="collapse">Close Me!</a>
			
					<div class="block">
						<h2><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
						<small><?php the_time('F j, Y'); ?></small>
						<p><?php the_content_rss('', TRUE, '', 25); ?><br/><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>">Read More...</a></p>
					</div>
				</div>
				
				<?php endif; ?> 
			</div> <!-- main_image -->
			
			<div class="image_thumb">
				<ul>
					<?php
						rewind_posts(); // Reuse the previous query.
						if (have_posts()) : while (have_posts()) : the_post();
					?>
					
					<li>
						<a href="<?php $src = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), array( 614,381 ), false, '' ); echo $src[0]; ?>"><?php the_post_thumbnail('featured-side'); ?></a>
						
						<div class="block">
							<h2><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
							<small><?php the_time('F j, Y'); ?></small>
							<p><?php the_content_rss('', TRUE, '', 25); ?><br/><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>">Read More...</a></p>
						</div>
					</li>
					
					<?php endwhile; else: ?>
					<?php endif; ?>		
				</ul>
			</div> <!-- image_thumb -->
		</div> <!-- home_featured -->
		
		<?php if (get_option(THEME_PREFIX . "home_announce")) { ?>
			<div id="home_announce">
				<a href="<?php echo get_option(THEME_PREFIX . "home_announce_link"); ?>" title="<?php echo get_option(THEME_PREFIX . "home_announce"); ?>"><?php echo get_option(THEME_PREFIX . "home_announce"); ?></a>
			</div>
		<?php } ?>

		<div id="main">
			<div class="home_left">
				<?php
					if ( get_option(THEME_PREFIX."home_left_type") == "post" )
						query_posts('cat=' . get_option(THEME_PREFIX."home_left_cat") . '&showposts=2');
					else
						query_posts('page_id=' . get_option(THEME_PREFIX."home_left_page"));
				?>
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				
				<div class="home_entry">
					<h2><?php the_title(); ?></h2>
					<?php the_excerpt(); ?>
					<p><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>">Read More...</a></p>
				</div>
				
				<?php endwhile; else: ?>
				<?php endif; ?>
				<?php wp_reset_query() ?>
			</div> <!-- home_left -->
			
			<div class="home_center">
				<?php
					if ( get_option(THEME_PREFIX."home_right_type") == "post" )
						query_posts('cat=' . get_option(THEME_PREFIX."home_right_cat") . '&showposts=2');
					else
						query_posts('page_id=' . get_option(THEME_PREFIX."home_right_page"));
				?>
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				
				<div class="home_entry">
					<h2><?php the_title(); ?></h2>
					<?php the_excerpt(); ?>
					<p><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>">Read More...</a></p>
				</div>
				
				<?php endwhile; else: ?>
				<?php endif; ?>
				<?php wp_reset_query() ?>
			</div> <!-- home_center -->
		</div> <!-- main -->
	
		<?php get_sidebar(); ?>

	</div> <!-- content_wrapper -->
	<div id="content_bottom"><!-- nothing to see here --></div>

<?php get_footer(); ?>
