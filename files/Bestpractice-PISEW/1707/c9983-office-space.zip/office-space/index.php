<?php get_header(); ?>

	<div id="content_top"><!-- nothing to see here --></div>
	<div id="content_wrapper">
		<div id="main">
			<?php if (have_posts()) : ?>
            <?php while (have_posts()) : the_post(); ?>  
            
            <div class="the_post <?php sticky_class(); ?>" id="post-<?php the_ID(); ?>"> 
                <h2><a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
                
                <div class="post_dets">
                    <span class="dets"><?php the_time('F jS, Y') ?> by <?php the_author() ?> </span>
                    <span class="dets">Categories: <?php the_category(', '); ?></span>
                    <span class="dets last_dets"><a href="<?php the_permalink() ?>#comments" title="<?php the_title_attribute(); ?>"><?php comments_number('No Responses','One Response','% Responses'); ?></a></span>
                </div>
                
                <div class="entry">
					<a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><img class="entry_thumb" src="<?php $src = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), array( 275,200 ), false, '' ); echo $src[0]; ?>" alt="<?php the_title_attribute(); ?>"/></a>
					
					<?php the_content('Continue Reading'); ?>
                </div>
            </div> <!-- the_post -->
            
            <div class="divider"><!-- nothing to see here --></div>
            
            <?php endwhile; ?>
            
			<div class="navigation">
				<div class="alignleft"><?php next_posts_link('&laquo; Older Entries') ?></div>
				<div class="alignright"><?php previous_posts_link('Newer Entries &raquo;') ?></div>
			</div>            
            
            <?php else : ?>    
            
            <div class="the_post"> 
                <h2>Try again...</h2>
            </div> <!-- the_post -->
            
            <?php endif; ?>
		</div> <!-- main -->
	
		<?php get_sidebar(); ?>
	</div> <!-- content_wrapper -->
	<div id="content_bottom"><!-- nothing to see here --></div>

<?php get_footer(); ?>