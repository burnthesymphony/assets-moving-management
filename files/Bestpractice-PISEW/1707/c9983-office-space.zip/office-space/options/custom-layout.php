<?php
	$option_fields[] = $two_column = THEME_PREFIX . "two_column";
	$option_fields[] = $minimum_width = THEME_PREFIX . "minimum_width";
	$option_fields[] = $fixed_width = THEME_PREFIX . "fixed_width";
	$option_fields[] = $fixed_width_width = THEME_PREFIX . "fixed_width_width";
?>

<div class="postbox">
    <h3>Custom Theme Layout Options</h3>
    
    <div class="inside">
    	<p>Massive News has a 3 column fluid width layout by default. Use the options below to configure alternate layout options.</p>
    
    	<div class="table">
    		<div class="row">
    			<div class="option">
    		    	<label for="<?php echo $two_column; ?>">
    		    	    <input class="checkbox" id="<?php echo $two_column; ?>" type="checkbox" name="<?php echo $two_column; ?>" value="true"<?php checked(TRUE, (bool) get_option($two_column)); ?> /> <?php _e("Two Column Layout"); ?>
    		    	</label>
    			</div>
    			
    			<div class="option-select">	
    				Minimum Width (Pixels): <input class="option-field-table" id="<?php echo $minimum_width; ?>" type="text" name="<?php echo $minimum_width; ?>" value="<?php echo get_option($minimum_width); ?>" />
    			</div>
    		</div>
    		
    		<div class="row last">
    	    	<div class="option">
    	        	<label for="<?php echo $fixed_width; ?>">
    	        	    <input class="checkbox" id="<?php echo $fixed_width; ?>" type="checkbox" name="<?php echo $fixed_width; ?>" value="true"<?php checked(TRUE, (bool) get_option($fixed_width)); ?> /> <?php _e("Fixed Width"); ?>
    	        	</label>
    			</div>
    			
    			<div class="option-select">	
    				Width (Pixels): <input class="option-field-table" id="<?php echo $fixed_width_width; ?>" type="text" name="<?php echo $fixed_width_width; ?>" value="<?php echo get_option($fixed_width_width); ?>" />
    			</div>
    		</div>
    		<div class="clearfix"></div>
    	</div>
    	
    	<p class="submit">
    		<input type="submit" class="button" value="Save Changes" />
    	</p>
    </div> <!-- inside -->
</div> <!-- postbox -->