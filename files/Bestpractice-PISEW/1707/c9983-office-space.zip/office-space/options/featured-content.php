<?php
	$option_fields[] = $feature_carousel = THEME_PREFIX . "feature_carousel";
	$option_fields[] = $home_left_type = THEME_PREFIX . "home_left_type";
	$option_fields[] = $home_right_type = THEME_PREFIX . "home_right_type";
	$option_fields[] = $home_left_cat = THEME_PREFIX . "home_left_cat";
	$option_fields[] = $home_right_cat = THEME_PREFIX . "home_right_cat";
	$option_fields[] = $home_left_page = THEME_PREFIX . "home_left_page";
	$option_fields[] = $home_right_page = THEME_PREFIX . "home_right_page";
	$published_pages = p75_get_published_pages();
?>

<div class="postbox">
    <h3>Featured Content Carousel</h3>
    
    <div class="inside">
    	<p>Select a category for which you wish to display posts within the Featured Content Carousel at the top of the home page.</p>
    
    	<div class="table">
    		<div class="row last">
    			<div class="option">
    				<label for="<?php echo $feature_carousel; ?>">Choose a category:</label>
    			</div>
    			
    			<div class="option-select">
    				<?php wp_dropdown_categories( array( 'name' => $feature_carousel, 'id' => $feature_carousel,'selected' => get_option($feature_carousel) ) ); ?>
    			</div>
    		</div>
    		
    		<div class="clearfix"></div>
    	</div>
    	
    	<p class="submit">
			<input type="submit" class="button" value="Save Changes" />
		</p>
    </div> <!-- inside -->
</div> <!-- postbox -->

<div class="postbox">
    <h3>Featured Content Columns</h3>
    
    <div class="inside">
    	<p>The home page has two content columns. Each column can either show the latest post from a selected category or an excerpt from a selected page.</p>
    	
    	<p class="option-label">Left Column:</p>
    	<div class="table">
    		<div class="row">
    			<div class="option">
    				<input id="<?php echo $home_left_type . "_post"; ?>" type="radio" name="<?php echo $home_left_type; ?>" value="post"<?php checked("post", get_option($home_left_type)); ?>>
    				<label for="<?php echo $home_left_type . "_post"; ?>">Latest post from a category.</label>
    			</div>
    			
    			<div class="option-select">
    				<?php wp_dropdown_categories( array( 'name' => $home_left_cat, 'id' => $home_left_cat,'selected' => get_option($home_left_cat) ) ); ?>
    			</div>
    		</div>
    		
    		<div class="row last">
    			<div class="option">
    				<input id="<?php echo $home_left_type . "_page"; ?>" type="radio" name="<?php echo $home_left_type; ?>" value="page"<?php checked("page", get_option($home_left_type)); ?>>
    				<label for="<?php echo $home_left_type . "_page"; ?>">Show page excerpt.</label>
    			</div>
    			
    			<div class="option-select">
    				<select id="<?php echo $home_left_page; ?>" name="<?php echo $home_left_page; ?>">
						<?php
							foreach ( $published_pages as $page ) {
								printf("<option value='%d'%s>%s</option>\n", $page->ID, selected($page->ID, get_option($home_left_page), false), $page->post_title);
							}
						?>
					</select>
    			</div>
    		</div>
    		
    		<div class="clearfix"></div>
    	</div>
    	
    	<p class="option-label">Right Column:</p>
    	<div class="table">
    		<div class="row">
    			<div class="option">
    				<input id="<?php echo $home_right_type . "_post"; ?>" type="radio" name="<?php echo $home_right_type; ?>" value="post"<?php checked("post", get_option($home_right_type)); ?>>
    				<label for="<?php echo $home_right_type . "_post"; ?>">Latest post from a category.</label>
    			</div>
    			
    			<div class="option-select">
    				<?php wp_dropdown_categories( array( 'name' => $home_right_cat, 'id' => $home_right_cat,'selected' => get_option($home_right_cat) ) ); ?>
    			</div>
    		</div>
    		
    		<div class="row last">
    			<div class="option">
    				<input id="<?php echo $home_right_type . "_page"; ?>" type="radio" name="<?php echo $home_right_type; ?>" value="page"<?php checked("page", get_option($home_right_type)); ?>>
    				<label for="<?php echo $home_right_type . "_page"; ?>">Show page excerpt.</label>
    			</div>
    			
    			<div class="option-select">
    				<select id="<?php echo $home_right_page; ?>" name="<?php echo $home_right_page; ?>">
						<?php
							foreach ( $published_pages as $page ) {
								printf("<option value='%d'%s>%s</option>\n", $page->ID, selected($page->ID, get_option($home_right_page), false), $page->post_title);
							}
						?>
					</select>
    			</div>
    		</div>
    		
    		<div class="clearfix"></div>
    	</div>
    	
    	<p class="submit">
			<input type="submit" class="button" value="Save Changes" />
		</p>
    </div> <!-- inside -->
</div> <!-- postbox -->