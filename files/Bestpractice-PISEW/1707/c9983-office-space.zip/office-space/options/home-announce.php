<?php
	$option_fields[] = $home_announce = THEME_PREFIX . "home_announce";
	$option_fields[] = $home_announce_link = THEME_PREFIX . "home_announce_link";
?>

<div class="postbox">
    <h3>Home Page Announcement</h3>
    
    <div class="inside">
    	<p>Enter some text below for the home page announcement (below the carousel).:</p>
    	<p>
    		<input class="option-field" id="<?php echo $home_announce; ?>" type="text" name="<?php echo $home_announce; ?>" value="<?php echo get_option($home_announce); ?>" />
    	</p>
    	
    	<p>Links to (e.g. "http://www.yoursite.com/announce-link/"):</p>
    	<p>
    		<input class="option-field-medium" id="<?php echo $home_announce_link; ?>" type="text" name="<?php echo $home_announce_link; ?>" value="<?php echo get_option($home_announce_link); ?>" />
    	</p>
    	
    	<p class="submit">
    		<input type="submit" class="button" value="Save Changes" />
    	</p>
    </div> <!-- inside -->
</div> <!-- postbox -->