<?php get_header(); ?>

	<div id="content_top"><!-- nothing to see here --></div>
	<div id="content_wrapper">
		<div id="main">
			<?php if (have_posts()) : ?>
            <?php while (have_posts()) : the_post(); ?>  
            
            <div class="the_post page_post" id="post-<?php the_ID(); ?>"> 
                <h2><a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
                
                <div class="post_dets">
                    <span class="dets"><?php the_time('F jS, Y') ?> by <?php the_author() ?> </span>
                </div>
                
                <div class="entry">
					<?php the_content('Continue Reading'); ?>
                </div>
            </div> <!-- the_post -->
            
            <?php endwhile; ?>
            <?php else : ?>    
            
            <div class="the_post"> 
                <h2>Sorry, but what you are looking for isn't here...</h2>
            </div> <!-- the_post -->
            
            <?php endif; ?>
		</div> <!-- main -->
	
		<?php get_sidebar(); ?>
	</div> <!-- content_wrapper -->
	<div id="content_bottom"><!-- nothing to see here --></div>

<?php get_footer(); ?>