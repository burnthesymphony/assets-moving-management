<?php get_header(); ?>

	<div id="content_top"><!-- nothing to see here --></div>
	<div id="content_wrapper">
		<div id="main">
			<?php if (have_posts()) : ?>
            <?php while (have_posts()) : the_post(); ?>  
            
            <div class="the_post <?php sticky_class(); ?>" id="post-<?php the_ID(); ?>"> 
                <h2><a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
                
                <div class="post_dets">
                    <span class="dets"><?php the_time('F jS, Y') ?> by <?php the_author() ?> </span>
                    <span class="dets">Categories: <?php the_category(', '); ?></span>
                    <span class="dets last_dets"><?php comments_number('No Responses','One Response','% Responses'); ?></span>
                </div>
                
				<?php echo get_video($post->ID); ?>
                
                <div class="entry">
					<?php the_content('Continue Reading'); ?>
                </div>
            </div> <!-- the_post -->
            
            <div class="divider"><!-- nothing to see here --></div>
            
            <?php comments_template(); ?>
            
            <?php endwhile; else: ?>
    		<?php endif; ?>	
		</div> <!-- main -->
	
		<?php get_sidebar(); ?>
	</div> <!-- content_wrapper -->
	<div id="content_bottom"><!-- nothing to see here --></div>

<?php get_footer(); ?>